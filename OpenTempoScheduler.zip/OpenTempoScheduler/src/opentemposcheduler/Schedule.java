/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package opentemposcheduler;

/**
 *
 * @author Taylor Robey
 */
public class Schedule {
    //create two arrays to track tasks
    //divide day into 204 5-minute segments, starting at 7:00 AM
        private Task[] SchedArray = new Task[204];
        private Task[] SecArray = new Task[204];
    //default constructor
    public Schedule(){
        SchedArray = new Task[204];
        SecArray = new Task[204];
    }
    
    //get functions
    
    public Task getTask1(int taskTime){
        return SchedArray[taskTime];
    }
    
    public Task getTask2(int taskTime){
        return SecArray[taskTime];
    }
    
    public boolean isFilled(int taskTime){
        boolean filled = false;
        if (SchedArray[taskTime] instanceof Task){
               filled = true;
        }
        return filled;
    }
    
    public boolean isFilled2(int taskTime){
        boolean filled = false;
        if (SecArray[taskTime] instanceof Task){
               filled = true;
        }
        return filled;
    }
    
    public int getSize(){
        return 204;
    }
    
    //set functions
    
    public String scheduleTask(Task toBeScheduled){
        //string to store possible error message
        String errorMessage = "";
        //find earliest empty location that can fit task
        int emptyLoc = -1;
        boolean isAvailable = false;
        //0 for SchedArray, 1 for SecArray
        int arrayChoice = -1;
        
        for(int i = 0; i<204 ;i++){
            //for empty spot, check to see if there is room for the task
            if (SchedArray[i] == null){
                isAvailable = roomAndCompat(toBeScheduled, i);
                arrayChoice = 0;
            }
            else if (SecArray[i] == null){
                isAvailable = roomAndCompat2(toBeScheduled, i);
                arrayChoice = 1;
            }
            
            //if room and compatibility check out, store the location
            if (isAvailable == true){
                emptyLoc = i;
                break;
            }
        }
        
        if (emptyLoc == -1){
            errorMessage = "Cannot schedule because there is no avaialable time for "+ toBeScheduled.getName()+ ".\n";
        }
        else{
            for(int i = emptyLoc; i<(emptyLoc+(toBeScheduled.getDuration()/5)); i++){
                if(arrayChoice == 0){
                    SchedArray[i] = toBeScheduled;
                }
                else if(arrayChoice == 1){
                    SecArray[i] = toBeScheduled;
                }
            }
        }
        return errorMessage;
    }
    
    public String scheduleTask(Task toBeScheduled, int reqStartTime){
        //string to store possible error message
        String errorMessage = "";
        //if desired location is empty in first array, add it
        if (!(SchedArray[reqStartTime] instanceof Task)){
            for(int i = reqStartTime; i<(reqStartTime+(toBeScheduled.getDuration()/5));i++){
                SchedArray[i] = toBeScheduled;
            }
        }
        //otherwise, see if it can go in the second array
        else if (!(SecArray[reqStartTime] instanceof Task)){
            //if the space is empty, check compatibility
            boolean iscompat = true;
            for(int i = reqStartTime; i<(reqStartTime+(toBeScheduled.getDuration()/5));i++){
                if ((SchedArray[i] instanceof Task)){
                    if(!(toBeScheduled.getCompatibility().contains(SchedArray[i].getID()))){
                       iscompat = false; 
                    }
                }
            }
            //if the new Task is compatible with all old tasks, put it in the schedule
            if (iscompat){
                for(int i = reqStartTime; i<(reqStartTime+(toBeScheduled.getDuration()/5));i++){
                    SecArray[i] = toBeScheduled;
                }
            }
            //otherwise, return an error message
            else {
                errorMessage = "Cannot schedule because "+ toBeScheduled.getName()+ " is not compatible with another task.\n";
            }
        }
        //otherwise, return an error message
        else{
            errorMessage = "Cannot schedule because "+ toBeScheduled.getName()+ " cannot be scheduled at the desired time.\n";
        }
        return errorMessage;
    }
    
    private boolean roomAndCompat(Task checkTask, int startTime){
        int duration = checkTask.getDuration()/5;
        //booleans to see if there is room & compatibility
        boolean isRoom = true;
        boolean isCompat = true;

        for (int j = startTime; j<(startTime+duration) ;j++){
            //check to see if space is empty
            if(SchedArray[j] != null){
                isRoom = false;
            }
            //check space of other array for compatibility
            if ((SecArray[j] instanceof Task)){
                if(!(checkTask.getCompatibility().contains(SecArray[j].getID()))){
                    isCompat = false; 
                }
            }
        }
        return (isRoom && isCompat);
    }
    
    private boolean roomAndCompat2(Task checkTask, int startTime){
        int duration = checkTask.getDuration()/5;
        //booleans to see if there is room & compatibility
        boolean isRoom = true;
        boolean isCompat = true;

        for (int j = startTime; j<(startTime+duration) ;j++){
            //check to see if space is empty
            if(SecArray[j] != null){
                isRoom = false;
            }
            //check space of other array for compatibility
            if ((SchedArray[j] instanceof Task)){
                if(!(checkTask.getCompatibility().contains(SchedArray[j].getID()))){
                    isCompat = false; 
                }
            }
        }
        return (isRoom && isCompat);
    }
}
