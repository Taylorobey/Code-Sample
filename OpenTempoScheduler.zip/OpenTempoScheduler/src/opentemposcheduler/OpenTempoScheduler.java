/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package opentemposcheduler;

import java.io.*;
import static java.lang.Integer.parseInt;
import java.util.*;

/**
 *
 * @author Taylor Robey
 */
public class OpenTempoScheduler {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException{
        
        //create arraylist to store tasks
        @SuppressWarnings("UnusedAssignment")
        ArrayList<Task> taskList = new ArrayList<>();
        
        //second arraylist to hold tasks with no specific time for sorting
        ArrayList<Task> sortList = new ArrayList<>();
        
        // create the main schedule object
        Schedule MainSchedule = new Schedule();
        
        //create string to hold possible error message
        String conflictReason ="";
        
        //assign tasks from file to arraylist
        taskList = fileRead("C:\\Users\\Taylor\\Documents\\NetBeansProjects\\OpenTempoScheduler\\tasks_to_complete.yml");
                
        // assign tasks with specific times to their timeslot
        for (Task taskList1 : taskList) {
            //if a task has a start time,  assign it to that time
            if (taskList1.getStart() != -1){
                conflictReason += MainSchedule.scheduleTask(taskList1, taskList1.getStart());
            }
        }
        
        // organize remaining tasks by decreasing size
        for (Task taskList1 : taskList) {
            //if the task has no start time, put it into the sorting array
            if (taskList1.getStart() == -1){
                //add to the sorted array in the proper position
                if (sortList.isEmpty()){
                    sortList.add(taskList1);
                }
                else{
                    int addIndex = 0;
                    boolean sorted = false;
                    for (Task sortList1 : sortList) {
                        //if duration of task to be inserted is equal to or less than the current task, add it at that position
                        int currentDur = sortList1.getDuration();
                        int toBeAddedDur = taskList1.getDuration();
                        if (currentDur < toBeAddedDur){
                            addIndex = sortList.indexOf(sortList1);
                            sorted = true;
                            break;
                        }
                    }
                    if (sorted){
                        sortList.add(addIndex, taskList1);
                    }
                    else{
                        sortList.add(taskList1);
                    }
                }
            }

        }
        
        //add tasks to schedule from sorted list
        for (Task sortList1 : sortList) {
            conflictReason += MainSchedule.scheduleTask(sortList1);
        }
        // output schedule
        TestSchedPrint(MainSchedule);
        
        //print out error message if nothing is scheduled
        if (!(printSchedule(MainSchedule))){
            System.out.println("Cannot make schedule: \n"+conflictReason);
        }
    }
    
    //function reads the file and returns an arraylist of task objects
    public static ArrayList<Task> fileRead(String filename) throws FileNotFoundException, IOException{
        //create an arraylist to store the records
        ArrayList<Task> tempList = new ArrayList<>();
        
        //create temporary variables to store values to put into new Task
        int tempID = 0;

        String tempname = "";

        int tempstart = -1;

        int tempduration = 0;
        
        ArrayList<Integer> tempCompList = new ArrayList<>();
        
        //boolean to see whether this is first task
        boolean notfirst = false;
        
        //string to store input from file
        String line;
        

        
        //read the file
        try(FileReader ioread = new FileReader(filename);
                BufferedReader buffer = new BufferedReader(ioread)){
            //as long as there is content in the next line
            while((line = buffer.readLine()) != null) {
                //split the input line at spaces and turn into a string array
                String[] temp = line.split("\\s+");
                
                // collect data to construct task object
                    /* test file output:
                        for (int i = 0; i<temp.length; i++){
                            System.out.println("Step "+i+": "+temp[i]);
                        }
                    */
                //if first item in array is the word "tasks", then ignore that line
                if (!"tasks:".equals(temp[0])){
                    //choose next action based on second item in temp array
                    switch(temp[1]){
                        /*if the second item is "-", 
                            the line either shows an ID or a 
                            compatibility number
                            */
                        case "-":
                            if("id:".equals(temp[2])){
                                //check to see whether this is a new item
                                if (notfirst == true){
                                    //create new record using colected input
                                    Task newTask = new Task (tempID, tempname, tempstart, tempduration, tempCompList);

                                    //add record to arraylist
                                    tempList.add(newTask);
                
                                    //reset temporary variables
                                    tempID = 0;
                                    tempname = "";
                                    tempstart = -1;
                                    tempduration = 0;
                                    tempCompList = new ArrayList<>();
                                }
                                else {
                                    notfirst = true;
                                }
                                // store the ID as a temp ID
                                tempID = Integer.parseInt(temp[3]);
                            }
                            //OR store the compatibility number
                            else{
                                tempCompList.add(Integer.parseInt(temp[2]));
                            }
                            break;
                        // if second item is description, record name
                        case "description:": 
                            for (int j = 2; j<temp.length; j++){
                                tempname += temp[j] + " ";
                            }
                            break;
                        // if second item is start, record start time
                        case "start:": 
                            if (!"null".equals(temp[2])){
                                //remove quotations
                                temp[2] = temp[2].substring(1, temp[2].length()-1);

                                //split into minutes and hours
                                String[] tempdur = temp[2].split(":");
                                int tempHour = Integer.parseInt(tempdur[0]);
                                int tempMin = Integer.parseInt(tempdur[1]);
                                
                                //convert into a start time integer for the Task
                                tempstart = (tempHour*12)+(tempMin/5)-(84);

                                
                            }
                            break;
                        // if second item is duration, record it
                        case "duration:": 
                            tempduration = Integer.parseInt(temp[2]);
                            break;
                        //
                        default: 
                            break;
                    }
                }
            }
            //create new record using colected input
            Task newTask = new Task (tempID, tempname, tempstart, tempduration, tempCompList);

            //add record to arraylist
            tempList.add(newTask);
            
            
        }
        return tempList;
    }
    
    /*    
    test methods:
    
    public static void OutputTasks(ArrayList<Task> dispList){
        for (Task dispList1 : dispList) {
            ArrayList<Integer> compList = dispList1.getCompatibility();
            System.out.println("ID: "+ dispList1.getID()+"\n");
            System.out.println("Name: "+ dispList1.getName()+"\n");
            System.out.println("Start: "+ dispList1.getStart()+"\n");
            System.out.println("Duration: "+ dispList1.getDuration()+"\n");
            System.out.println("Compatibility: ");
            for (Integer compList1 : compList) {
                System.out.println(" "+ compList1);
            }
            System.out.println("\n");
        }
    }
    
    
    */
 
    
    public static void TestSchedPrint(Schedule testSchedule){
        for(int i=0; i<testSchedule.getSize();i++){
            String taskName = "";
            if(testSchedule.isFilled(i)){
                taskName = testSchedule.getTask1(i).getName();
            }
            System.out.println(i+": "+taskName);
        }
        for(int i=0; i<testSchedule.getSize();i++){
            String taskName = "";
            if(testSchedule.isFilled2(i)){
                taskName = testSchedule.getTask2(i).getName();
            }
            System.out.println(i+": "+taskName);
        }
    }
    
    public static boolean printSchedule(Schedule toPrint){
        boolean scheduled = false;
        
        
        for(int i=0; i<toPrint.getSize();i++){
            Task comp1 = null;
            Task comp2 = null;
            //get tasks for the timeslot
            if(toPrint.isFilled(i)){
                comp1 = toPrint.getTask1(i);
                scheduled = true;
            }
            if(toPrint.isFilled2(i)){
                comp2 = toPrint.getTask2(i);
                scheduled = true;
            }
            
            //display tasks if they have not already been displayed, sorted by duration
            if (comp1 !=null && !comp1.getDisplayed() && comp2 != null && !comp2.getDisplayed()){
                if (comp1.getDuration()>comp2.getDuration()){
                    Task tempSwitch = comp1;
                    comp1 = comp2;
                    comp2 = tempSwitch;
                }
            }
            if (comp1 !=null && !comp1.getDisplayed()){
                int starthour = 7+(i/12);
                int startmin = 0+((i%12)*5);
                int endhour = 7+(((i*5)+comp1.getDuration())/60);
                int endmin = 0+(((i*5)+comp1.getDuration())%60);
                System.out.println(comp1.getName()+": "+starthour+":"+((startmin<10) ? "0" : "")+startmin+"-"+endhour+":"+((endmin<10) ? "0" : "")+endmin);
            }
            if (comp2 !=null && !comp2.getDisplayed()){
                int starthour = 7+(i/12);
                int startmin = 0+((i%12)*5);
                int endhour = 7+(((i*5)+comp2.getDuration())/60);
                int endmin = 0+(((i*5)+comp2.getDuration())%60);
                System.out.println(comp2.getName()+": "+starthour+":"+((startmin<10) ? "0" : "")+startmin+"-"+endhour+":"+((endmin<10) ? "0" : "")+endmin);
            }
            if (toPrint.getTask1(i) != null){
               toPrint.getTask1(i).setDispalyed(true); 
            }
            if (toPrint.getTask2(i) != null){
               toPrint.getTask2(i).setDispalyed(true); 
            }            
        }
        return scheduled;
    }

}


