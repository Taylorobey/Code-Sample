/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package opentemposcheduler;

import java.util.ArrayList;

/**
 *
 * @author Taylor Robey
 */
public class Task{
        // the ID of the task, to cross reference compatibility
        private int ID = 0;
        // the name of the task, for final display
        private String name = "";
        //the required starting time, as an integer indicating 5-minute intervals from 7:00 AM
        //-1 indicates no requirement
        private int start = -1;
        //the duration in minutes
        private int duration = 0;
        // a list of compatible activities' IDs
        private ArrayList<Integer> compatibility = new ArrayList<>();
        //boolean to tell if task has alredy been displayed
        private boolean displayed;
    
    //default constuctor
    public Task(){
        this.displayed = false;
        ID = 0;
        name = "";
        start = -1;
        duration = 0;
        compatibility = new ArrayList<>();
        displayed = false;
    }
    
    //constructor for storing tasks in the schedule
    //start time and duration are unneeded due to way that schedule class is organized
    public Task(int taskID, String taskName, ArrayList<Integer> taskCompatibility){
        this.displayed = false;
        ID = taskID;
        name = taskName;
        compatibility = taskCompatibility;
        displayed = false;
    }
    
    //constructor using information from yml file
    public Task(int ymlID, String ymlName, int ymlStart, int ymlDuration, ArrayList<Integer> ymlCompatibility){
        this.displayed = false;
        ID = ymlID;
        name = ymlName;
        start = ymlStart;
        duration = ymlDuration;
        compatibility = ymlCompatibility;
        displayed = false;
    }
    
    //get functions
    public int getID(){
        return ID;
    }
    
    public String getName(){
        return name;
    }
    
    public int getStart(){
        return start;
    }
    
    public int getDuration(){
        return duration;
    }
    
    public ArrayList<Integer> getCompatibility(){
        return compatibility;
    }
    
    public boolean getDisplayed(){
        return displayed;
    }
    
    //set function
    
    public void setDispalyed(boolean toSet){
        displayed = toSet;
    }
    
}
